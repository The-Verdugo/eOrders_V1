﻿Imports System.Web
Imports System.Web.Services
Imports System.Web.Services.Protocols
Imports System.Data
Imports System.Configuration
Imports System.Data.SqlClient
Imports System.Xml

Module Funciones

    Public Function ObtieneItems(ByVal CodCli As String, ByVal CodItem As String, ByVal Alm As String, ByVal SerLot As String) As DataTable
        Dim Resp As DataTable
        Dim constr As String = ConfigurationManager.ConnectionStrings("SQLConnection").ConnectionString
        Using con As New SqlConnection(constr)
            Using cmd As New SqlCommand("EXECUTE " & ToolReadSettings("sp_eO_Items", "[DESARROLLOSGVI].[dbo].[sp_eO_Items]") & " @CardCode, @ItemCode, @WhsCode, @LoteSerie")
                cmd.Parameters.AddWithValue("@CardCode", CodCli)
                cmd.Parameters.AddWithValue("@ItemCode", CodItem)
                cmd.Parameters.AddWithValue("@WhsCode", Alm)
                cmd.Parameters.AddWithValue("@LoteSerie", SerLot)
                Using sda As New SqlDataAdapter()
                    cmd.Connection = con
                    sda.SelectCommand = cmd
                    Using dt As New DataTable()
                        dt.TableName = "OITM"
                        sda.Fill(dt)
                        Resp = dt.Copy()
                        dt.Clear()
                        dt.Dispose()
                    End Using
                    sda.Dispose()
                End Using
                cmd.Dispose()
            End Using
            con.Close()
            con.Dispose()
            ClearMemory()
        End Using
        Return Resp
    End Function
    Public Function ObtieneDirs(ByVal CodCli As String) As DataTable
        Dim Resp As DataTable
        Dim constr As String = ConfigurationManager.ConnectionStrings("SQLConnection").ConnectionString
        Using con As New SqlConnection(constr)
            Using cmd As New SqlCommand("EXECUTE " & ToolReadSettings("sp_eO_Addrs", "[DESARROLLOSGVI].[dbo].[sp_eO_Addrs]") & " @CardCode")
                cmd.Parameters.AddWithValue("@CardCode", CodCli)
                Using sda As New SqlDataAdapter()
                    cmd.Connection = con
                    sda.SelectCommand = cmd
                    Using dt As New DataTable()
                        dt.TableName = "CRD1"
                        sda.Fill(dt)
                        Resp = dt.Copy()
                        dt.Clear()
                        dt.Dispose()
                    End Using
                    sda.Dispose()
                End Using
                cmd.Dispose()
            End Using
            con.Close()
            con.Dispose()
            ClearMemory()
        End Using
        Return Resp
    End Function

    Public Sub ObtieneLista(ByVal CodCliente As String, ByRef listTP As ListBox)
        Dim dtResp As DataTable
        Dim constr As String = ConfigurationManager.ConnectionStrings("SQLConnection").ConnectionString
        Using con As New SqlConnection(constr)
            Using cmd As New SqlCommand("EXECUTE " & ToolReadSettings("sp_eO_Listas", "[DESARROLLOSGVI].[dbo].[sp_eO_Listas]") & " @CardCode")
                cmd.Parameters.AddWithValue("@CardCode", CodCliente)
                Using sda As New SqlDataAdapter()
                    cmd.Connection = con
                    sda.SelectCommand = cmd
                    Using dt As New DataTable()
                        dt.TableName = "OCRD"
                        sda.Fill(dt)
                        dtResp = dt.Copy()
                        dt.Clear()
                        dt.Dispose()
                    End Using
                    sda.Dispose()
                End Using
                cmd.Dispose()
            End Using
            con.Close()
            con.Dispose()
            Try
                If dtResp.Rows.Count >= 1 Then
                    listTP.Items.Clear()
                    listTP.DataSource = dtResp
                    listTP.DataTextField = "Nombre"
                    listTP.DataValueField = "Codigo"
                    listTP.DataBind()
                Else
                    'SQL Caido
                End If
            Catch ex As Exception
                ' = ex.Message
            End Try
            ClearMemory()
        End Using
    End Sub

    Public Function ObtieneCardName(ByVal CodCliente As String) As String
        Dim getData As String = ""
        Dim dtResp As DataTable
        Dim constr As String = ConfigurationManager.ConnectionStrings("SQLConnection").ConnectionString
        Using con As New SqlConnection(constr)
            Using cmd As New SqlCommand("EXECUTE " & ToolReadSettings("sp_eO_CardName", "[DESARROLLOSGVI].[dbo].[sp_eO_CardName]") & " @CardCode")
                cmd.Parameters.AddWithValue("@CardCode", CodCliente)
                Using sda As New SqlDataAdapter()
                    cmd.Connection = con
                    sda.SelectCommand = cmd
                    Using dt As New DataTable()
                        dt.TableName = "OCRD"
                        sda.Fill(dt)
                        dtResp = dt.Copy()
                        dt.Clear()
                        dt.Dispose()
                    End Using
                    sda.Dispose()
                End Using
                cmd.Dispose()
            End Using
            con.Close()
            con.Dispose()
            Try
                If dtResp.Rows.Count >= 1 Then
                    getData = dtResp.Rows.Item(0).Item(0).ToString
                Else
                    'SQL Caido
                    getData = "El datatable no contiene información"
                End If
            Catch ex As Exception
                getData = ex.Message
            End Try
            ClearMemory()
        End Using
        Return getData
    End Function
    Public Function ObtieneWhsName(ByVal CodAlmacen As String) As String
        Dim getWhsName As String = ""
        Dim dtResp As DataTable
        Dim constr As String = ConfigurationManager.ConnectionStrings("SQLConnection").ConnectionString
        Using con As New SqlConnection(constr)
            Using cmd As New SqlCommand("EXECUTE " & ToolReadSettings("sp_eO_WhsName", "[DESARROLLOSGVI].[dbo].[sp_eO_WhsName]") & " @WhsCode")
                cmd.Parameters.AddWithValue("@WhsCode", CodAlmacen)
                Using sda As New SqlDataAdapter()
                    cmd.Connection = con
                    sda.SelectCommand = cmd
                    Using dt As New DataTable()
                        dt.TableName = "OWHS"
                        sda.Fill(dt)
                        dtResp = dt.Copy()
                        dt.Clear()
                        dt.Dispose()
                    End Using
                    sda.Dispose()
                End Using
                cmd.Dispose()
            End Using
            con.Close()
            con.Dispose()
            Try
                If dtResp.Rows.Count >= 1 Then
                    getWhsName = dtResp.Rows.Item(0).Item(0).ToString
                Else
                    'SQL Caido
                    getWhsName = "El datatable no contiene información"
                End If
            Catch ex As Exception
                getWhsName = ex.Message
            End Try
            ClearMemory()
        End Using
        Return getWhsName
    End Function

    Public Function IniciarSesion(ByVal Usuario As String, ByVal Pass As String) As DataTable
        Dim Resp As DataTable
        Dim constr As String = ConfigurationManager.ConnectionStrings("SQLConnection").ConnectionString
        Using con As New SqlConnection(constr)
            Using cmd As New SqlCommand("EXECUTE " & ToolReadSettings("sp_eO_Login", "[DESARROLLOSGVI].[dbo].[sp_eO_Login]") & " @Usuario, @Pass")
                cmd.Parameters.AddWithValue("@Usuario", Usuario)
                cmd.Parameters.AddWithValue("@Pass", Pass)
                Using sda As New SqlDataAdapter()
                    cmd.Connection = con
                    sda.SelectCommand = cmd
                    Using dt As New DataTable()
                        dt.TableName = "OUSR"
                        sda.Fill(dt)
                        Resp = dt.Copy()
                        dt.Clear()
                        dt.Dispose()
                    End Using
                    sda.Dispose()
                End Using
                cmd.Dispose()
            End Using
            con.Close()
            con.Dispose()
            ClearMemory()
        End Using
        Return Resp
    End Function

    Public Function ValidaUsr(ByVal Usuario As String) As DataTable
        Dim Resp As DataTable
        Dim constr As String = ConfigurationManager.ConnectionStrings("SQLConnection").ConnectionString
        Using con As New SqlConnection(constr)
            Using cmd As New SqlCommand("EXECUTE " & ToolReadSettings("sp_eO_ValidaUsr", "[DESARROLLOSGVI].[dbo].[sp_eO_ValidaUsr]") & " @Usuario")
                cmd.Parameters.AddWithValue("@Usuario", Usuario)
                Using sda As New SqlDataAdapter()
                    cmd.Connection = con
                    sda.SelectCommand = cmd
                    Using dt As New DataTable()
                        dt.TableName = "OUSR"
                        sda.Fill(dt)
                        Resp = dt.Copy()
                        dt.Clear()
                        dt.Dispose()
                    End Using
                    sda.Dispose()
                End Using
                cmd.Dispose()
            End Using
            con.Close()
            con.Dispose()
            ClearMemory()
        End Using
        Return Resp
    End Function

    '//*************************************************************
    '// Limpiamos memoria a nivel proceso
    '//*************************************************************
    Public Declare Auto Function SetProcessWorkingSetSize Lib "kernel32.dll" (ByVal procHandle As IntPtr, ByVal min As Int32, ByVal max As Int32) As Boolean
    Public Sub ClearMemory()
        Try
            Dim Mem As System.Diagnostics.Process
            Mem = System.Diagnostics.Process.GetCurrentProcess()
            SetProcessWorkingSetSize(Mem.Handle, -1, -1)
        Catch ex As Exception
            'Control de errores
        End Try
    End Sub

    '//*************************************************************
    '// Lee la configuración del sistema
    '//*************************************************************
    Public Function ToolReadSettings(Keys As String, DefaultValue As String) As String
        Dim val As String = ""
        Try
            Dim appSettings = System.Configuration.ConfigurationManager.AppSettings
            For Each key As String In appSettings.AllKeys
                If Keys = key Then
                    val = appSettings(key)
                End If
            Next
            If val = "" Then
                Try
                    val = DefaultValue
                    Dim configFile = System.Configuration.ConfigurationManager.OpenExeConfiguration(System.Configuration.ConfigurationUserLevel.None)
                    Dim settings = configFile.AppSettings.Settings
                    If IsNothing(settings(Keys)) Then
                        settings.Add(Keys, DefaultValue)
                    Else
                        settings(Keys).Value = DefaultValue
                    End If
                    configFile.Save(System.Configuration.ConfigurationSaveMode.Modified)
                    System.Configuration.ConfigurationManager.RefreshSection(configFile.AppSettings.SectionInformation.Name)
                Catch e As System.Configuration.ConfigurationErrorsException

                End Try
            End If
        Catch e As System.Configuration.ConfigurationErrorsException

        End Try
        Return val
    End Function

End Module
